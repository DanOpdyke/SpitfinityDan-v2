using UnityEngine;
using System.Collections;

public class Helm : Armor, Item {
	
	public Helm() {
		this.Name = "Helm";
		this.texturePath = "HelmTextures/texture";
		this.numTextures = 4;
	}

	public void Equip(){
		
	}
	
	public int getItemRarity(){
		return this.itemRarity;
	}
	
	public Item getCopy(){
		return new Helm();
	}
	
	public void randomize(int level){
		this.randomizeArmor(level);	
	}
}
