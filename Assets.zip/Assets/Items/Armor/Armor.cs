using UnityEngine;
using System.Collections;

public abstract class Armor : MonoBehaviour, Item {
	
	#region Armor Stats
	private int strength;
	
	public int Strength {
		get
		{	
			return this.strength;
		}
		set
		{
			strength = value;
		}
	}
	
	private int dexterity;

	public int Dexterity {
		get {
			return this.dexterity;
		}
		set {
			dexterity = value;
		}
	}	
	
	private int intelligence;
	
	private int vitality;

	public int Intelligence {
		get {
			return this.intelligence;
		}
		set {
			intelligence = value;
		}
	}

	public int Vitality {
		get {
			return this.vitality;
		}
		set {
			vitality = value;
		}
	}	

	public string Name {
		get {
			return this.name;
		}
		set {
			name = value;
		}
	}

	private string name;

	public int ItemRarity {
		get {
			return this.itemRarity;
		}
		set {
			itemRarity = value;
		}
	}

	public Texture2D Texture {
		get {
			return this.texture;
		}
		set {
			texture = value;
		}
	}
	#endregion
	
	protected Texture2D texture;
	protected string texturePath;
	protected int itemRarity;
	protected int numTextures;
	
	protected string[] prefixes = { "Torn", "Worn", "Woven", "Sturdy", "Reinforced", "Heavy"};
	protected string[] suffixes = {"Power", "Quickness", "Wisdom", "Fortitude"};
	
	
	/*
	 * Legendaries:
	 * Warmogs, Sunfire Cape, Randuin's Omen, Rabadon's Deathcap
	 * 
	 * Fake Legendaries:
	 * Madred's BeardShaver
	 * Frozen Fart //TODO DELETE (maybe?)
	 * */
	
	public Texture2D getTexture(){
		return texture;
	}
	
	public void Equip(PlayerScript player){
		player.Strength += this.Strength;
		player.Dexterity += this.Dexterity;
		player.Intelligence += this.Intelligence;
		player.Vitality += this.Vitality;
	}
	
	public int getItemRarity(){
		return itemRarity;
	}
	
	public string getStats(){
		string toReturn = Name + "\n";
		if(Strength > 0)
			toReturn += "Strength: " + Strength + "\n";
		if(Dexterity > 0)
			toReturn += "Dexterity: " + Dexterity + "\n";
		if(Intelligence > 0)
			toReturn += "Intelligence: " + Intelligence + "\n";
		if(Vitality > 0)
			toReturn += "Vitality: " + Vitality + "\n";
		
		return toReturn;
	}
	
	public Item getCopy(){
		return null;
	}
	
	public void randomize(int level){
		this.randomizeArmor(level);	
	}
	
	public void randomizeArmor(int level, int forcedRartiy = -1){
		float rarityPercent = Random.value;
		if(forcedRartiy > -1)
			itemRarity = forcedRartiy;
		else{
		//Fortitute, Quickness, Wisdom, Power
			if(rarityPercent <= 0.3f)
				itemRarity = 0;
			else if(rarityPercent <= 0.6f)
				itemRarity = 1;
			else if(rarityPercent <= 0.80f)
				itemRarity = 2;
			else if(rarityPercent <= 0.90f)
				itemRarity = 3;
			else if(rarityPercent <= 0.96f)
				itemRarity = 4;
			else
				itemRarity = 5;
		}
		
		float effectiveWeaponLevel = Random.value * level * Mathf.Pow(2, itemRarity);
		
		//Allow each item to have up to three stats on it
		for(int i = 0; i < 3; i++)
		{
			int amountToIncrease = (int) Random.Range(1+effectiveWeaponLevel, 10 + effectiveWeaponLevel);
			increaseStat(Random.Range(0, 4), amountToIncrease);
		}
		int highestStatIndex = 0;
		int highestStat = strength;
		if(dexterity > highestStat){
			highestStat = dexterity;
			highestStatIndex = 1;
		}
		if(intelligence > highestStat){
			highestStat = intelligence;
			highestStatIndex = 2;
		}
		if(vitality > highestStat){
			highestStat = dexterity;
			highestStatIndex = 3;
		}
		
		Name = prefixes[itemRarity] + " " + Name + " of " + suffixes[highestStatIndex];
		texturePath += Random.Range(0, numTextures);
		texture = Resources.Load(texturePath) as Texture2D;
		
		
	}
	
	protected void increaseStat(int statNum, int amount){
		switch(statNum){
		case 0:
			this.Strength += amount;
			goto default;
		case 1:
			this.Dexterity += amount;
			goto default;
		case 2:
			this.Intelligence += amount;
			goto default;
		case 3:
			this.Vitality += amount;
			goto default;
		default:
			break;
		}
	}
	
	//<summary>
	//Saves item in standard format.
	//Type, Name, Rarity, Str, Dex, Int, Vit, TexturePath
	//</summary>
	public string Save(){
		string toReturn = "Armor, " + this.GetType().ToString();
		string Conn = ",";
		toReturn += Conn + this.name;
		toReturn += Conn + this.itemRarity;
		toReturn += Conn + this.strength;
		toReturn += Conn + this.dexterity;
		toReturn += Conn + this.intelligence;
		toReturn += Conn + this.vitality;
		toReturn += Conn + this.texturePath;
		return toReturn;
	}
	
			//<summary>
	//Loads item assuming string in standard format.
	//Type, Name, Rarity, Str, Dex, Int, Vit, TexturePath
	//</summary>
	public static Armor Load(string savedData){
		string[] data = savedData.Split(',');
		Armor armor = (Armor) System.Activator.CreateInstance(null, data[1]).Unwrap();
		armor.Name = data[2];
		armor.ItemRarity = int.Parse(data[3]);
		armor.Strength = int.Parse(data[4]);
		armor.Dexterity = int.Parse(data[5]);
		armor.Intelligence = int.Parse(data[6]);
		armor.Vitality = int.Parse(data[7]);
		armor.texturePath = data[8];
		armor.Texture = (Texture2D) Resources.Load(data[8]);
		return armor;
	}
}
