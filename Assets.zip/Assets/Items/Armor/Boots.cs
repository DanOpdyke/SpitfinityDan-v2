using UnityEngine;
using System.Collections;

public class Boots : Armor, Item {
	
	public Boots() {
		this.Name = "Boots";
		this.texturePath = "BootTextures/texture";
		this.numTextures = 8;
	}
	
	public void Equip(){
		
	}
		
	public int getItemRarity(){
		return this.itemRarity;
	}
	
	public Item getCopy(){
		return new Boots();
	}
	
	public void randomize(int level){
		this.randomizeArmor(level);	
	}

}
