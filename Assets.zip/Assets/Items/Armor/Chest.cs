using UnityEngine;
using System.Collections;

public class Chest : Armor, Item {
	
	public void Equip(){
		
	}
	
	public Chest() {
		this.Name = "Chest";
		this.texturePath = "ChestTextures/texture";
		this.numTextures = 10;
	}
		
	public int getItemRarity(){
		return this.itemRarity;
	}
	
	public Item getCopy(){
		return new Chest();
	}
	
	public void randomize(int level){
		this.randomizeArmor(level);	
	}
}
