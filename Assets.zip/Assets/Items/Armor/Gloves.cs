using UnityEngine;
using System.Collections;

public class Gloves : Armor, Item {
	
	public void Equip(){
		;
	}
	
	public Gloves() {
		this.Name = "Gloves";
		this.texturePath = "GlovesTextures/texture";
		this.numTextures = 4;
	}
	
	public int getItemRarity(){
		return this.itemRarity;
	}
	
	public Item getCopy(){
		return new Gloves();
	}
	
	public void randomize(int level){
		this.randomizeArmor(level);	
	}
}
