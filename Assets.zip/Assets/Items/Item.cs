using UnityEngine;
using System.Collections;

public interface Item {
	
	Texture2D getTexture();
	
	void Equip(PlayerScript player);
	
	string getStats();
	
	int getItemRarity();
	
	Item getCopy();
	
	void randomize(int level);
	
	string Save();
}
