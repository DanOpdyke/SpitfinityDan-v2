using UnityEngine;
using System.Collections;

public class Ability : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	// Executes the ability
	void Execute(){
	}
}
