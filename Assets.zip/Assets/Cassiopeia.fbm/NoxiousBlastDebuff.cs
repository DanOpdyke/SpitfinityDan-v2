using UnityEngine;
using System.Collections;

public class NoxiousBlastDebuff : MonoBehaviour, Debuff {
	private float expirationTime;
	private float duration = 8;
	
	private float damage = 5;
	private float nextTickTime;
	private float timeBetweenTicks = 2;
	
	private PlayerScript player;
	
	private Texture2D texture;
	
	public NoxiousBlastDebuff() {
		expirationTime = Time.time + duration;
		texture = Resources.Load("Debuffs/NoxiousBlast") as Texture2D;
	}

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	}

	#region Debuff implementation
	public bool hasExpired ()
	{
		return Time.time > expirationTime;
	}

	public float applyDebuff (float damage)
	{
		return damage;
	}

	public void applyStack (int numAdditionalStacks)
	{
		; //Noxious Blast does not stack.
	}

	public Texture2D getTexture ()
	{
		return texture;
	}

	public void apply (PlayerScript player)
	{
		player.setPoisoned(true);
	}

	public void expire (PlayerScript player)
	{
		player.setPoisoned(false);
	}

	public bool stackable ()
	{
		return false;
	}

	public bool prolongable ()
	{
		return true;
	}
	
	public void refresh() {
		expirationTime = Time.time + duration;
	}
	
	public string description() {
		return "Noxious Blast \n Suffer " + damage + " damage every " + timeBetweenTicks + " seconds. ";	
	}
	
	public string name() {
		return "Noxious Blast";	
	}
	
	public void update(){
		if(Time.time > nextTickTime){
			nextTickTime = Time.time + timeBetweenTicks;
			player.damage(damage);
		}
	}
	#endregion
}
