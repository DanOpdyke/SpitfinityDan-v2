using UnityEngine;
using System.Collections;

public class MiasmaScript : MonoBehaviour {
	private float nextTick = Time.time + 4;
	private float lifeTime;
	private float currentScale = 1;
	
	// Use this for initialization
	void Start () {
		lifeTime = Time.time + 10;
	}
	
	// Update is called once per frame
	void Update () {
		if(Time.time > lifeTime)
			Destroy(gameObject);
	}
	
	public void trigger(PlayerScript player){
		if (Time.time > nextTick){
			MiasmaDebuff debuff = new MiasmaDebuff(player);
			player.applyDebuff(debuff);
			currentScale += .2f;
			
			gameObject.transform.localScale = Vector3.one * currentScale;
			nextTick = Time.time + 1;
		}
	}
}
