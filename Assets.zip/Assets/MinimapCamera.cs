using UnityEngine;
using System.Collections;

public class MinimapCamera : MonoBehaviour {
	GameObject player;
	float aspectRatio;
	Camera camera;
	
	// Use this for initialization
	void Start () {
		camera = gameObject.GetComponent(typeof(Camera)) as Camera;
	}
	
	// Update is called once per frame
	void Update () {
		aspectRatio = Screen.height / (float) Screen.width;
		float height = 0.22f;
		float width = height * aspectRatio;
		
		camera.rect = new Rect(1 - width, 1 - height, width, height);
		
		if(player == null)
			player = GameObject.FindGameObjectWithTag("TopLevelObject") as GameObject;
		Vector3 newPosition = player.transform.position;
		newPosition.y = gameObject.transform.position.y;
		gameObject.transform.position = newPosition;
	}
}
