using UnityEngine;
using System.Collections;

public class CourageBuff : MonoBehaviour, Debuff {
	private float expirationTime;
	private float duration = 3;
	private Texture2D texture;
	
	public CourageBuff(){
		texture = Resources.Load("GarenTextures/Courage") as Texture2D;
		expirationTime = Time.time + duration;
	}
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	#region Debuff implementation
	bool Debuff.hasExpired ()
	{
		return Time.time > expirationTime;
	}

	float Debuff.applyDebuff (float damage)
	{
		return damage;
	}

	void Debuff.applyStack (int numAdditionalStacks)
	{
		;
	}

	Texture2D Debuff.getTexture ()
	{
		return texture;
	}

	void Debuff.apply (PlayerScript player)
	{
		;
	}

	void Debuff.expire (PlayerScript player)
	{
		;
	}

	bool Debuff.stackable ()
	{
		return false;
	}

	bool Debuff.prolongable ()
	{
		return false;
	}

	void Debuff.refresh ()
	{
		expirationTime = Time.time + duration;
	}

	string Debuff.description ()
	{
		return "Garen is taking 30% less damage.";
	}

	string Debuff.name ()
	{
		return "Courage";
	}

	void Debuff.update ()
	{
		;
	}
	#endregion
}
