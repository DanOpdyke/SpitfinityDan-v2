using UnityEngine;
using System.Collections;

public class SwiftDeathDebuff : MonoBehaviour, Debuff {
	private float expirationTime;
	private float duration = 5;
	private float damage;
	private float nextTick;
	private EnemyScript enemy;
	private Texture2D texture;
	
	public SwiftDeathDebuff(EnemyScript enemy){
		this.enemy = enemy;
		texture = Resources.Load("Debuffs/SwiftDeath") as Texture2D;
		expirationTime = Time.time + duration;
		damage = (GameObject.FindGameObjectWithTag("Player").GetComponent(typeof(PlayerScript)) as PlayerScript).WeaponDamage;
	}
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	#region Debuff implementation
	bool Debuff.hasExpired ()
	{
		return Time.time > expirationTime;
	}

	float Debuff.applyDebuff (float damage)
	{
		return damage;
	}
	
	public void update(){
		if(Time.time >= nextTick){
			nextTick = Time.time + 1;
			enemy.damage(damage / 5);
		}
	}

	void Debuff.applyStack (int numAdditionalStacks)
	{
		;//This debuff cannot be stacked
	}

	Texture2D Debuff.getTexture ()
	{
		return texture;
	}

	void Debuff.apply (PlayerScript player)
	{
		damage = player.WeaponDamage * 0.1f;
	}

	void Debuff.expire (PlayerScript player)
	{
		;
	}

	bool Debuff.stackable ()
	{
		return false;
	}

	bool Debuff.prolongable ()
	{
		return true;
	}

	void Debuff.refresh ()
	{
		expirationTime = Time.time + duration;
	}

	string Debuff.description ()
	{
		return "The target is bleeding for " + damage + " damage over 5 seconds.";
	}

	string Debuff.name ()
	{
		return "Shadow Death";
	}
	#endregion
}
