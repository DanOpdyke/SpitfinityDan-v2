using UnityEngine;
using System.Collections;

public class FinalHourBuff : MonoBehaviour, Debuff {
	private float expireTime;
	private float duration = 8.4f;
	private Texture2D texture;
	
	public FinalHourBuff(){
		texture = Resources.Load("Debuffs/FinalHour") as Texture2D;
		expireTime = Time.time + duration;
	}
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	#region Debuff implementation
	bool Debuff.hasExpired ()
	{
		return expireTime < Time.time;
	}

	float Debuff.applyDebuff (float damage)
	{
		return damage;
	}

	void Debuff.applyStack (int numAdditionalStacks)
	{
		;
	}

	Texture2D Debuff.getTexture ()
	{
		return texture;
	}

	void Debuff.apply (PlayerScript player)
	{
		;
	}

	void Debuff.expire (PlayerScript player)
	{
		;
	}

	bool Debuff.stackable ()
	{
		return false;
	}

	bool Debuff.prolongable ()
	{
		return false;
	}

	void Debuff.refresh ()
	{
		;
	}

	string Debuff.description ()
	{
		return "Vayne deals 40% bonus damage and \n heals for 50% of damage caused.";
	}

	string Debuff.name ()
	{
		return "FinalHour";
	}

	void Debuff.update ()
	{
		;
	}
	#endregion
}
