using UnityEngine;
using System.Collections;

public class TumbleBuff : MonoBehaviour, Debuff {
	private bool expired;
	private Texture2D texture;
	private VayneScript player;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	#region Debuff implementation
	bool Debuff.hasExpired ()
	{
		return expired;
	}

	float Debuff.applyDebuff (float damage)
	{
		
		expired = true;
		return damage;
	}

	void Debuff.applyStack (int numAdditionalStacks)
	{
		;
	}

	Texture2D Debuff.getTexture ()
	{
		return texture;
	}

	void Debuff.apply (PlayerScript player)
	{
		if(texture == null)
			texture = Resources.Load("Debuffs/Tumble") as Texture2D;;
	}

	void Debuff.expire (PlayerScript player)
	{
		;
	}

	bool Debuff.stackable ()
	{
		return false;
	}

	bool Debuff.prolongable ()
	{
		return false;
	}

	void Debuff.refresh ()
	{
		;
	}

	string Debuff.description ()
	{
		return "Vayne's next attack will do \n 30% additional damage.";
	}

	string Debuff.name ()
	{
		return "TumbleBuff";
	}
	
	public void update(){
		;
	}
	#endregion
}
