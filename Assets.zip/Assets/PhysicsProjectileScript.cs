using UnityEngine;
using System.Collections;

public class PhysicsProjectileScript : MonoBehaviour {
	private Rigidbody rigidbody;
	private Vector3 destination;
	private float timeToLive;
	private float speed;
	private float damage;
	
	// Use this for initialization
	void Start () {
		this.rigidbody = gameObject.GetComponent(typeof(Rigidbody)) as Rigidbody;
		timeToLive = Time.time + 10;
	}
	
	public void setDamage(float damage){
		this.damage = damage;
	}
	
	public void setSpeed(float speed){
		this.speed = speed;
	}
	
	public void setTimeToLive(float timeToLive){
		this.timeToLive = timeToLive;	
	}
	
	public void setDestination(Vector3 destination){
		this.destination = destination;
		gameObject.transform.LookAt(destination);
		if(rigidbody == null)
			rigidbody = gameObject.GetComponent(typeof(Rigidbody)) as Rigidbody;
		rigidbody.velocity = transform.forward * speed;
	}
	
	// Update is called once per frame
	void Update () {
		if(timeToLive < Time.time)
			Destroy(gameObject);
	}
	
	void OnTriggerEnter(Collider collision){
		if(collision.gameObject == GameObject.FindGameObjectWithTag("Player")){
			PlayerScript player = collision.gameObject.GetComponent(typeof(PlayerScript)) as PlayerScript;
			player.damage(damage);
			Destroy(gameObject);
		}
	}
		
}
