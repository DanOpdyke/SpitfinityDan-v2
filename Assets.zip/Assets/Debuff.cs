using UnityEngine;
using System.Collections;

public interface Debuff {
	
	// Returns boolean indicating if the debuff is expired
	bool hasExpired();
	
	// Calculate how this debuff affects damage done
	float applyDebuff(float damage);
	
	// Applies additional stacks of the debuff
	void applyStack(int numAdditionalStacks);
	
	Texture2D getTexture();
	
	void apply(PlayerScript player);
	
	void expire(PlayerScript player);
	
	bool stackable();
	
	bool prolongable();
	
	void refresh();
	
	string description();
	
	string name();
	
	void update();
}
