using UnityEngine;
using System.Collections;

public class SpawnZoneScript : MonoBehaviour {
	
	/// <summary>
	/// List of spawn points for this spawn zone. To save space, the y component of each vector3 is an index
	/// indicated the type of enemy to be spawned.
	/// </summary>
	private ArrayList spawnPoints;
	private GameObject[] instantiateObjects;
	private int numPossibleTypes = 3;
	private string[] enemyTypeIds = {"M", "C", "B1"};
	public string locationID;
	
	/// <summary>
	/// Determines if this spawn zone has already been triggered. Once a spawn zone has been triggered, it must be manually
	/// reset before it will spawn more enemies.
	/// </summary>
	private bool triggered;
	
	
	// Use this for initialization
	void Start () {
		instantiateObjects = new GameObject[numPossibleTypes];
		instantiateObjects[0] = GameObject.FindGameObjectWithTag("MeleeMinion");
		instantiateObjects[1] = GameObject.FindGameObjectWithTag("CasterMinion");
		instantiateObjects[2] = GameObject.FindGameObjectWithTag("Cassiopeia");
		
		
		spawnPoints = new ArrayList();
		System.IO.StreamReader reader = new System.IO.StreamReader("SpawnLocations/"+locationID+".txt");
		while(!reader.EndOfStream){
			string[] locations = reader.ReadLine().Split(',');
			Vector3 data = new Vector3(float.Parse(locations[1]), (float) System.Array.IndexOf(enemyTypeIds, locations[0]), float.Parse(locations[2]));
			spawnPoints.Add(data);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	private void spawnUnits(){
		foreach(Vector3 positionData in spawnPoints){
			//Instantiate new object
			GameObject newEnemy = (GameObject) Instantiate(instantiateObjects[(int)positionData.y]);
			
			//Each enemy has a different y position. As such, we ensure that only the x and z positions
			//are set.
			Vector3 newPosition = positionData;
			newPosition.y = newEnemy.transform.position.y;
			newEnemy.transform.position = newPosition;
		}
	}
	
	public void setTriggered(bool triggered){
		this.triggered = triggered;	
	}
	
	void OnTriggerEnter(Collider other){
		//Only trigger once
		if(triggered)
			return;
		PlayerScript player = other.gameObject.GetComponent(typeof(PlayerScript)) as PlayerScript;
		if(player != null){
			spawnUnits();
			triggered = true;
		}
	}
}
