using UnityEngine;
using System.Collections;

public class SeekingProjectileScript : MonoBehaviour {
	private float speed;
	private float damage;
	private GameObject target;
	private float hitDistance = 1;
	private float nullTimeout = 0;
	private float nullTimeoutDelay = 10;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(target == null){
			if(nullTimeout > 0 && Time.time > nullTimeout)
				Destroy(gameObject);
			else if (nullTimeout == 0)
				nullTimeout = Time.time + nullTimeoutDelay;
		}
		else
			nullTimeout = 0;
		
		if(Vector3.Distance(gameObject.transform.position, target.transform.position) < hitDistance){
			PlayerScript player = target.GetComponent(typeof(PlayerScript)) as PlayerScript;
			if(player != null)
				player.damage(damage);
			else{
				EnemyScript enemy = target.GetComponent(typeof(EnemyScript)) as EnemyScript;
				enemy.damage(damage);
			}
				Destroy(gameObject);
		}
		else{
			//Face target
			Vector3 lookat = target.transform.position;
			lookat.y = gameObject.transform.position.y;
			gameObject.transform.LookAt(lookat);
			//Move towards target
			gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, target.transform.position, speed);
		}
	}
	
	public void setSpeed(float speed){
		this.speed = speed;
	}
	
	public void setDamage(float damage){
		this.damage = damage;	
	}
	
	public void setTarget(GameObject target){
		this.target = target;
	}
}
