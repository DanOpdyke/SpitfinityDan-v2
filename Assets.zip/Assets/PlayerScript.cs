using UnityEngine;
using System.Collections;

public interface PlayerScript {
	
	#region Player Stats
	int Strength
	{
		get;
		set;
	}
	
	int Dexterity
	{
		get;
		set;
	}
	
	int Intelligence
	{
		get;
		set;
	}
	
	int Vitality
	{
		get;
		set;
	}
	
	float WeaponDamage
	{
		get;
		set;
	}
	
	float WeaponSpeed
	{
		get;
		set;
	}
	
	float MovementSpeed
	{
		get;
		set;
	}
	
	int Level
	{
		get;
		set;
	}
	#endregion
	
	void playIdleSequence();
	
	bool isRunAnimation();
	
	bool noAnimation();
	
	bool isAlive();
	
	void stopAnimation();
	
	float getHealthPercent();
	
	void setCurrentEnemy(EnemyScript enemy);
	
	void setIdling(bool idle);

	EnemyScript getCurrentEnemy();
	
	float getWeaponDamage();
	
	float getWeaponSpeed();
	
	void playAnimation(string animationName);
	
	void setRunning(bool active);
	
	float getRange();

	void awardHealth(float amount);

	void damage(float amount);
	
	float autoAttack(EnemyScript enemy);
	
	GameObject getGameObject();
	
	bool guiInteraction(Vector3 mousePosition);
	
	void awardItem(Item item);
	
	bool stunned();
	
	void Stun(float time);
	
	void setPoisoned(bool poisoned);
	
	bool isPoisoned();
	
	void applyDebuff(Debuff debuff);
	
	void Save();
	
	void setWin(bool win);
}
