using UnityEngine;
using System.Collections;

public interface PlayerScript {
	
	void playIdleSequence();
	
	bool isRunAnimation();
	
	bool noAnimation();
	
	bool isAlive();
	
	void stopAnimation();
	
	float getHealthPercent();
	
	void setCurrentEnemy(MinionScript enemy);
	
	void setIdling(bool idle);

	MinionScript getCurrentEnemy();
	
	float getWeaponDamage();
	
	float getWeaponSpeed();
	
	void playAnimation(string animationName);
	
	void setRunning(bool active);
	
	float getRange();

	void awardHealth(float amount);

	void damage(float amount);
	
	float autoAttack(MinionScript enemy);
	
	GameObject getGameObject();
}
