using UnityEngine;
using System.Collections;

public class BuildingOpacityScript : MonoBehaviour {
	GameObject player;
	MeshRenderer oldRenderer;
	public Material transparentMaterial;
	public Material originalMaterial;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(player == null)
			player = GameObject.FindGameObjectWithTag("Player");
		
		Vector3 dest = player.transform.position;
		dest.z += 20;
		Ray ray = new Ray(gameObject.transform.position, (player.gameObject.transform.position - gameObject.transform.position).normalized);
		RaycastHit hit;
		
		//Reset old materials. This will be overriden if the renderer is still being hit.
		if(oldRenderer != null)
			oldRenderer.material = originalMaterial;
		
		int layermask = 1 << 10;
		
		Debug.DrawRay(gameObject.transform.position, (player.gameObject.transform.position - gameObject.transform.position).normalized * 1000, Color.yellow);
		if(Physics.Raycast(ray, out hit, 10000, layermask)){
			MeshCollider collider = (MeshCollider) hit.collider;
			if(collider != null){
				MeshRenderer renderer = collider.gameObject.GetComponent(typeof(MeshRenderer)) as MeshRenderer;
				renderer.material = transparentMaterial;
				oldRenderer = renderer;
			}
		}
		
	}
}
