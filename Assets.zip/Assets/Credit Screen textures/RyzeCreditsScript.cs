using UnityEngine;
using System.Collections;

public class RyzeCreditsScript : MonoBehaviour {
	Animation animator;
	string[] clips = {"Idle1", "Idle2", "Laugh", "Taunt"};
	
	// Use this for initialization
	void Start () {
		animator = GetComponent(typeof(Animation)) as Animation;
	}
	
	// Update is called once per frame
	void Update () {
		if(!animator.isPlaying)
		{
			animator.Play(clips[Random.Range(0, 4)]);	
		}
	}
}