using UnityEngine;
using System.Collections;

public class CheckpointScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnTriggerEnter(Collider other){
		PlayerScript player = other.GetComponentInChildren(typeof(PlayerScript)) as PlayerScript;
		if(player != null){
			player.Save();	
		}
		else{
			Debug.Log("Entered area, but could not find PlayerScript");
		}
	}
}
